/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Manager.java
 * Author: Duc Ta
 * @author: <Mya > <Phyu>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class Manager extends Person {

    //
    // Instance Data Fields
    //

    private String Name;


    //
    // Constructors
    //
    public Manager() {
    }
    
    public Manager(String Name){

   this.Name= Name;


 }

    //
    // Instance Methods
    //
    public void ManagerDetails(){


   }

    @Override
    public void sayGreeting(String string) {

    }

    //
    // Language
    //

    //
    // Override
    //

}