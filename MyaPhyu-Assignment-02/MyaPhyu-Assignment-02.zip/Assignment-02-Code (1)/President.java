/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: President.java
 * Author: Duc Ta
 * @author: <Mya > <Phyu>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class President extends Person {

    //
    // Instance Data Fields
    //

    private Person person;


    //
    // Constructors
    //
    public President() {
    }




    //
    // Instance Methods
    //
    public void PresidentDetails()

    {

    }

    @Override
    public void sayGreeting(String string) {

    }

    @Override
    public String toString() {
        return "President{" +
                "person=" + person +
                '}';
    }
    //
    // Language
    //

    //
    // Override
    //




    //    }  
}
